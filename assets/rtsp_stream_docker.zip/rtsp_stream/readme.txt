### 1. insert videos that you want to stream to ./videos

### 2. edit file name on row 27 of docker-compose.yaml

### 3. run by 
$ sudo docker compose up -d

### 4. if you want to connect rtsp
url = rtsp://<IP-address>:8554/teststream

